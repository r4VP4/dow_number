# dow-to-number

The day of the week is coded different in the various systems and code-systems.
This is just the beginning, feel free to add more code-systems.